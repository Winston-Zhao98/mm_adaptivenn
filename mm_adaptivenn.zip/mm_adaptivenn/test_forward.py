"""
End-to-end smoke test — build model, forward pass, losses, AC checks.
Runs entirely on CPU with no network required (pretrained weights disabled).
Delete this file after passing or keep for CI.
"""
import sys, torch
sys.path.insert(0, '.')

from configs.default import get_config
from models.mm_adaptivenn import MMAdaptiveNN
from training.losses import (
    loss_rep, loss_rl, loss_value,
    compute_rewards, compute_advantages,
)
from utils.grad_checks import run_all_checks

# ── Minimal config (no pretrained download) ───────────────────────────────────
cfg = get_config()
cfg.model.modalities   = [1]       # vision-only
cfg.model.num_classes  = 10
cfg.model.d            = 64
cfg.model.d_s          = 128
cfg.model.d_h          = 128
cfg.language.d_z       = 64
cfg.training.T         = 2
cfg.device             = 'cpu'

# Use ResNet50 (torchvision, no HuggingFace) and skip pretrained download
cfg.encoder.vision_backbone  = 'resnet50'
cfg.encoder.vision_pretrained = 'none'   # tells factory: pretrained=False
cfg.language.backbone = 'clip'           # falls back to transformers CLIP if needed

print("=" * 60)
print("1. Building MMAdaptiveNN (random weights, no download)")
print("=" * 60)
model = MMAdaptiveNN(cfg)
n_train = sum(p.numel() for p in model.parameters() if p.requires_grad)
n_total = sum(p.numel() for p in model.parameters())
print(f"   Trainable params : {n_train:,}")
print(f"   Total params     : {n_total:,}")

# ── Dummy inputs ──────────────────────────────────────────────────────────────
B    = 2
X    = {1: torch.randn(B, 3, 128, 128)}
w    = ["classify the image", "identify the object"]
y    = torch.zeros(B, dtype=torch.long)
stop = MMAdaptiveNN._stop_distribution(cfg.training.T, 0.5, torch.device('cpu'))

print("\n" + "=" * 60)
print("2. AC constraint checks (training mode, gradients enabled)")
print("=" * 60)
model.train()
z    = model.encode_language(w)
traj = model.perception_loop(X, z, cfg.training.T, stop, greedy=False)
model.zero_grad(set_to_none=True)

ok = run_all_checks(model, X, w, traj=traj)
assert ok, "AC constraint check FAILED"

print("\n" + "=" * 60)
print("3. Tensor shape checks")
print("=" * 60)
print(f"   z shape           : {z.shape}       expect [{B}, {cfg.language.d_z}]")
print(f"   y_hat shape       : {traj['y_hat'].shape}  expect [{B}, {cfg.training.T}, {cfg.model.num_classes}]")
print(f"   s_sg.requires_grad: {traj['s_sg'].requires_grad}   expect False  (AC-2 stop-gradient)")
print(f"   s_full.req_grad   : {traj['s_full'].requires_grad}    expect True   (BPTT path)")
print(f"   log_pi shape      : {traj['log_pi'].shape}       expect [{B}, {cfg.training.T}]")
print(f"   v_t shape         : {traj['v_t'].shape}       expect [{B}, {cfg.training.T}]")
assert not traj['s_sg'].requires_grad, "AC-2 FAIL: s_sg must be detached"
assert traj['s_full'].requires_grad,   "BPTT FAIL: s_full must carry gradient"

print("\n" + "=" * 60)
print("4. Loss computations")
print("=" * 60)
model.train()
z2    = model.encode_language(w)
traj2 = model.perception_loop(X, z2, cfg.training.T, stop, greedy=False)

l_rep = loss_rep(traj2['y_hat'], y, stop)
rd    = compute_rewards(traj2['y_hat'], y, stop, gamma=cfg.training.gamma)
adv   = compute_advantages(rd['returns'], traj2['v_t'], normalise=True)
l_rl  = loss_rl(traj2['log_pi'], adv)
l_val = loss_value(traj2['v_t'], rd['returns'])

print(f"   L_rep  = {l_rep.item():.4f}   finite: {l_rep.isfinite().item()}")
print(f"   L_rl   = {l_rl.item():.4f}   finite: {l_rl.isfinite().item()}")
print(f"   L_val  = {l_val.item():.4f}   finite: {l_val.isfinite().item()}")
assert l_rep.isfinite(), "L_rep is not finite"
assert l_rl.isfinite(),  "L_rl  is not finite"
assert l_val.isfinite(), "L_val is not finite"

print("\n" + "=" * 60)
print("5. Backward pass — BPTT through Psi from L_rep")
print("=" * 60)
l_rep.backward()
psi_grads = [
    (name, p.grad.abs().max().item())
    for name, p in model.psi.named_parameters()
    if p.grad is not None
]
assert psi_grads, "No gradient reached theta_Psi via L_rep — BPTT broken"
for name, gmax in psi_grads[:5]:   # print first 5 params
    print(f"   psi.{name:35s}  grad_max = {gmax:.2e}  OK")
if len(psi_grads) > 5:
    print(f"   ... (+{len(psi_grads)-5} more psi params with gradients)")

print("\n" + "=" * 60)
print("ALL CHECKS PASSED ✓")
print("=" * 60)
